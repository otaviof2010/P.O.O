import exerciocio2 as e


f1 = Filme('star_wars', 2001, 4)
f2 = Filme('harry potter', 2000, 5)
