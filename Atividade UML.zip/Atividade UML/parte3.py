from abc import ABC,abstractmethod
from math import pi

class Forma(ABC):
    
    @abstractmethod
    def area(self) -> float:
        pass

    def descrever(self):
        return f"Área = {self.area():.2f}"
    
class Circulo(Forma):
    def __init__(self, raio):
        self.raio = raio
    
    def area(self) -> float:
        return pi *self.raio **2

class Retangulo(Forma):
    def __init__(self, base, altura):
        self.base = base
        self.altura = altura

    def area(self) -> float:
        return self.base * self.altura

class TrianguloExterno:
    def __init__(self, base, altura):
        self.base = base
        self.altura = altura

    def area(self) -> float:
        return (self.base * self.altura) / 2


def calcular_area_total(formas: list) -> float:
    total = 0

    for forma in formas:
        total += forma.area()  # Duck Typing

    return total

c1 = Circulo(5)
r1 = Retangulo(4, 6)
t1 = TrianguloExterno(10, 8)

print(c1.descrever())
print(r1.descrever())

print(f"Área do triângulo: {t1.area():.2f}")

formas = [c1, r1, t1]

print(f"\nÁrea total: {calcular_area_total(formas):.2f}")
